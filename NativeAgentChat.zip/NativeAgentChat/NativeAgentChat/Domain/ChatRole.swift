import Foundation

enum ChatRole: String, Codable, Sendable {
    case user
    case assistant
    case system
    case tool
}
